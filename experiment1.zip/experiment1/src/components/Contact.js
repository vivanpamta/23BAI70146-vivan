import React from "react";

function Contact() {
  return (
    <div className="box">
      <h2>Contact Page</h2>
      <p>This is the Contact page.</p>
    </div>
  );
}

export default Contact;
