import React from "react";

function About() {
  return (
    <div className="box">
      <h2>About Page</h2>
      <p>This is the About page.</p>
    </div>
  );
}

export default About;
